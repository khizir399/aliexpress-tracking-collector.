// AliExpress Tracking Collector - background service worker
// Opens each order's tracking page in ONE pinned, inactive tab, reads the
// tracking number, then closes the tab and moves on to the next order.

const TRACK_URL = (id) =>
  `https://www.aliexpress.com/p/tracking/index.html?_addShare=no&_login=yes&tradeOrderId=${id}`;

let running = false;
let stopRequested = false;
let keepAlive = null;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function getState() {
  const { state } = await chrome.storage.local.get("state");
  return state || { orders: [], results: {}, running: false, current: null };
}
async function setState(patch) {
  const state = await getState();
  Object.assign(state, patch);
  await chrome.storage.local.set({ state });
  return state;
}
async function setResult(id, result) {
  const state = await getState();
  state.results[id] = { ...(state.results[id] || {}), ...result };
  await chrome.storage.local.set({ state });
}

// Runs inside the AliExpress page: waits for the tracking number to render.
function readTrackingFromPage() {
  return new Promise((resolve) => {
    const started = Date.now();
    const TIMEOUT = 25000;

    const look = () => {
      const url = location.href.toLowerCase();
      if (url.includes("login.aliexpress") || url.includes("/login") || url.includes("passport.")) {
        return { error: "Not logged in to AliExpress" };
      }
      const text = document.body ? document.body.innerText : "";
      const m = text.match(/Tracking number:?\s*([A-Za-z0-9\-]{6,40})/i);
      if (m) {
        const carrierMatch = text.match(/AliExpress[^\n:]*:\s*([^\n]{2,30})\n/i);
        return { tracking: m[1], carrier: carrierMatch ? carrierMatch[1].trim() : "" };
      }
      if (/no tracking information|tracking information is not available|not shipped yet/i.test(text)) {
        return { error: "No tracking yet" };
      }
      return null;
    };

    const tick = () => {
      const found = look();
      if (found) return resolve(found);
      if (Date.now() - started > TIMEOUT) return resolve({ error: "Timed out (tracking number not found)" });
      setTimeout(tick, 600);
    };
    tick();
  });
}

function waitForTabComplete(tabId, timeout = 30000) {
  return new Promise((resolve) => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      chrome.tabs.onUpdated.removeListener(listener);
      clearTimeout(timer);
      resolve();
    };
    const listener = (id, info) => {
      if (id === tabId && info.status === "complete") finish();
    };
    chrome.tabs.onUpdated.addListener(listener);
    const timer = setTimeout(finish, timeout);
    chrome.tabs.get(tabId).then((t) => t.status === "complete" && finish()).catch(finish);
  });
}

async function fetchTracking(tabId, orderId) {
  await chrome.tabs.update(tabId, { url: TRACK_URL(orderId) });
  await sleep(500); // let navigation start so we don't read the previous page
  await waitForTabComplete(tabId);
  const [injection] = await chrome.scripting.executeScript({
    target: { tabId },
    func: readTrackingFromPage,
  });
  return injection?.result || { error: "No result from page" };
}

async function runQueue() {
  if (running) return;
  running = true;
  stopRequested = false;
  keepAlive = setInterval(() => chrome.runtime.getPlatformInfo(), 20000);

  let tabId = null;
  try {
    const state = await setState({ running: true, current: null });
    const pending = state.orders.filter((id) => {
      const r = state.results[id];
      return !r || r.status !== "done";
    });

    // One pinned tab, opened in the background so focus is never stolen.
    const tab = await chrome.tabs.create({ url: "about:blank", active: false, pinned: true });
    tabId = tab.id;

    for (const id of pending) {
      if (stopRequested) break;
      await setState({ current: id });
      await setResult(id, { status: "working", error: "" });

      let result;
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          result = await fetchTracking(tabId, id);
        } catch (e) {
          result = { error: String(e.message || e) };
          // tab may have been closed by the user: open a new pinned one
          try { await chrome.tabs.get(tabId); } catch {
            const t = await chrome.tabs.create({ url: "about:blank", active: false, pinned: true });
            tabId = t.id;
          }
        }
        if (result.tracking || result.error === "Not logged in to AliExpress") break;
        await sleep(1500);
      }

      if (result.tracking) {
        await setResult(id, { status: "done", tracking: result.tracking, carrier: result.carrier || "", error: "" });
      } else {
        await setResult(id, { status: "failed", tracking: "", error: result.error || "Unknown error" });
        if (result.error === "Not logged in to AliExpress") break; // no point continuing
      }
      await sleep(1500 + Math.random() * 1500); // be gentle with AliExpress
    }
  } finally {
    if (tabId !== null) chrome.tabs.remove(tabId).catch(() => {});
    clearInterval(keepAlive);
    running = false;
    await setState({ running: false, current: null });
  }
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "start") {
    runQueue();
    sendResponse({ ok: true });
  } else if (msg.type === "stop") {
    stopRequested = true;
    sendResponse({ ok: true });
  }
  return true;
});

// If the worker was restarted mid-run, clear the stale "running" flag.
chrome.runtime.onStartup.addListener(() => setState({ running: false, current: null }));
chrome.runtime.onInstalled.addListener(() => setState({ running: false, current: null }));
