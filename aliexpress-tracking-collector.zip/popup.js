const $ = (id) => document.getElementById(id);
const els = {
  orders: $("orders"), start: $("start"), stop: $("stop"), bar: $("bar"), fill: $("bar-fill"),
  notice: $("notice"), summary: $("summary"), resSec: $("results-section"), list: $("results"),
  format: $("format"), copyAll: $("copy-all"), csv: $("csv"), clear: $("clear"),
};

let state = { orders: [], results: {}, running: false, current: null };

const parseOrders = (text) => {
  const ids = text.match(/\d{12,}/g) || [];
  return [...new Set(ids)];
};

function formatRows(kind) {
  return state.orders.map((id) => {
    const t = state.results[id]?.tracking || "";
    if (kind === "tracking") return t;
    if (kind === "tracking-order") return `${t}\t${id}`;
    return `${id}\t${t}`;
  }).join("\n");
}

async function copy(text, btn, label) {
  await navigator.clipboard.writeText(text);
  const old = btn.textContent;
  btn.textContent = label || "Copied";
  setTimeout(() => (btn.textContent = old), 1200);
}

function render() {
  const { orders, results, running, current } = state;
  const done = orders.filter((id) => results[id]?.status === "done").length;
  const failed = orders.filter((id) => results[id]?.status === "failed").length;

  els.resSec.hidden = orders.length === 0;
  els.start.disabled = running;
  els.stop.hidden = !running;
  els.bar.hidden = !running;
  els.orders.disabled = running;
  els.fill.style.width = orders.length ? `${((done + failed) / orders.length) * 100}%` : "0";
  els.start.textContent = running ? "Collecting…" : failed ? "Retry failed and new orders" : "Collect tracking numbers";

  if (!orders.length) els.summary.textContent = "Paste order numbers to begin.";
  else if (running) els.summary.textContent = `Working on ${current || "…"} (${done + failed + 1} of ${orders.length})`;
  else els.summary.textContent = `${done} of ${orders.length} collected${failed ? `, ${failed} failed` : ""}`;

  const loginIssue = orders.some((id) => results[id]?.error === "Not logged in to AliExpress");
  els.notice.hidden = !loginIssue;
  if (loginIssue) els.notice.textContent = "Sign in to AliExpress in this Chrome profile, then retry.";

  els.list.replaceChildren();
  for (const id of orders) {
    const r = results[id] || {};
    const li = document.createElement("li");
    const oid = document.createElement("div"); oid.className = "oid"; oid.textContent = id;
    const trk = document.createElement("div");
    trk.className = "trk";
    if (r.status === "done") {
      trk.textContent = r.tracking;
      if (r.carrier) { const c = document.createElement("span"); c.className = "carrier"; c.textContent = r.carrier; trk.append(c); }
    } else if (r.status === "working") { trk.classList.add("working"); trk.textContent = "Reading page…"; }
    else if (r.status === "failed") { trk.classList.add("failed"); trk.textContent = r.error || "Failed"; }
    else { trk.classList.add("pending"); trk.textContent = "Waiting"; }
    li.append(oid, trk);
    if (r.status === "done") {
      const b = document.createElement("button");
      b.className = "ghost copy-one"; b.textContent = "Copy";
      b.onclick = () => copy(r.tracking, b);
      li.append(b);
    }
    els.list.append(li);
  }
  els.copyAll.disabled = done === 0;
  els.csv.disabled = done === 0;
}

els.start.onclick = async () => {
  const typed = parseOrders(els.orders.value);
  const orders = typed.length ? [...new Set([...state.orders, ...typed])] : state.orders;
  if (!orders.length) { els.orders.focus(); return; }
  const results = { ...state.results };
  for (const id of orders) if (results[id]?.status === "failed") delete results[id];
  state = { ...state, orders, results };
  await chrome.storage.local.set({ state });
  els.orders.value = "";
  chrome.runtime.sendMessage({ type: "start" });
};
els.stop.onclick = () => chrome.runtime.sendMessage({ type: "stop" });
els.copyAll.onclick = () => copy(formatRows(els.format.value), els.copyAll, "Copied all");
els.csv.onclick = () => {
  const rows = ["order_id,tracking_number", ...state.orders.map((id) => `${id},${state.results[id]?.tracking || ""}`)];
  const url = URL.createObjectURL(new Blob([rows.join("\n")], { type: "text/csv" }));
  const a = document.createElement("a");
  a.href = url; a.download = "aliexpress-tracking.csv"; a.click();
  URL.revokeObjectURL(url);
};
els.clear.onclick = async () => {
  if (state.running) return;
  state = { orders: [], results: {}, running: false, current: null };
  await chrome.storage.local.set({ state });
};
els.format.onchange = () => chrome.storage.local.set({ format: els.format.value });

chrome.storage.onChanged.addListener((changes) => {
  if (changes.state) { state = changes.state.newValue || state; render(); }
});

(async () => {
  const saved = await chrome.storage.local.get(["state", "format"]);
  if (saved.state) state = saved.state;
  if (saved.format) els.format.value = saved.format;
  render();
})();
